package POJO.CustomerOperations;

public class AuthenticateUser {
	
	private String AccountNumber;
	private String Password;
	
	public String getAccountNumber() {
		return AccountNumber;
	}
	
	public void setAccountNumber(String accountNumber) {
		AccountNumber = accountNumber;
		
	}
	
	public String getPassword() {
		return Password;
	}
	
	public void setPassword(String password) {
		Password = password;
	}
	
}
